
const manhattan = (x, y, endX, endY) => Math.abs(x - endX) + Math.abs(y - endY);

module.exports = {
	manhattan
};